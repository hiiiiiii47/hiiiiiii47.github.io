package com.github.instagram4j.instagram4j.requests;

public interface IGPaginatedRequest {
    void setMax_id(String s);
}
