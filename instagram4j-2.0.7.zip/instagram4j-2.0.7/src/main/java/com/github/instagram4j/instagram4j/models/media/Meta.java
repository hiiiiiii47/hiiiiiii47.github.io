package com.github.instagram4j.instagram4j.models.media;

public interface Meta {
    int getWidth();
    int getHeight();
    String getUrl();
}
