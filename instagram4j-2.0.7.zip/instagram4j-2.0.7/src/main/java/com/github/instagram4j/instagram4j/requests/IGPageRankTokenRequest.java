package com.github.instagram4j.instagram4j.requests;

public interface IGPageRankTokenRequest {
    void setPage_token(String token);

    void setRank_token(String token);
}
